<template>
  <section class="container">
    <Header />
    <nuxt-link to="/users">Users</nuxt-link>
  </section>
</template>

<script>
export default {
}
</script>

<template>
  <h1>An error occurred, we're sorry!</h1>
</template>

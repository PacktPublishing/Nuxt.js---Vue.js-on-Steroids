<template>
  <div>
    <Header />
    <header>
      USERS SECTION
    </header>
    <nuxt/>
  </div>
</template>

<script>
import Header from '@/components/Header'

export default {
  components: {
    Header
  }
}
</script>


<style>
</style>

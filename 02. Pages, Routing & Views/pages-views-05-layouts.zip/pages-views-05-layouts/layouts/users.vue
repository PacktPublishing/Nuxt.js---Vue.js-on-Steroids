<template>
  <div>
    <header>
      USERS SECTION
    </header>
    <nuxt/>
  </div>
</template>

<style>
</style>

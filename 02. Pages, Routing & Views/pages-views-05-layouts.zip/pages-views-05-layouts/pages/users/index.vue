<template>
  <p>Please enter an id and click the button.</p>
</template>

<script>
export default {
  layout: 'users'
}
</script>

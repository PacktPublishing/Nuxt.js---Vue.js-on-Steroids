<template>
  <h1>A single user, with ID: {{ $route.params.id }}</h1>
</template>
